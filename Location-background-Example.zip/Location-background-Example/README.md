# Location-background-Example(Android Jetpack).
Get Location from Background in android.

### This Example Show's:-
1) How to get Location from Background every hour.
2) How to get Location from Background using WorkManager or PeriodicWorkRequest.
3) How to get Location and save latitude and longitude using room persistence library.
4) Check if Work is Scheduled or Not in WorkManager.
